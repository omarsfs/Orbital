import datetime
import pytz
from telegram.ext import CallbackContext

job_data = {}

async def send_reminder(context: CallbackContext):
    job = context.job
    job_obj = job_data.get(job)
    if job_obj:
        event = job_obj['event']
        userid = job_obj['userid']
        message = f"Reminder: You have an upcoming deadline for {event} in 1 hour"
        await context.bot.send_message(chat_id=userid, text=message)

def add_reminder(event: str, datetimetask: str, userid: str, context: CallbackContext):
    try:
        datetime_obj = datetime.datetime.strptime(datetimetask, '%Y-%m-%d %H:%M')
        tz = pytz.timezone('Asia/Singapore')
        datetime_obj = tz.localize(datetime_obj)

        reminder_time = datetime_obj - datetime.timedelta(hours=1)

        # Store necessary data in the job_data dictionary
        job_obj = {'event': event, 'userid': userid, 'datetime' : datetime_obj}

        # Schedule the reminder and store the job object itself as context data
        job = context.job_queue.run_once(send_reminder, reminder_time)
        job_data[job] = job_obj  

        return f'Reminder set for {event} on {datetime_obj.strftime("%Y-%m-%d %H:%M")}'
    except ValueError:
        return "Invalid format. To set a reminder, please use the format: \nevent, YYYY-MM-DD HH:MM\nFor example, Hall Application, 2023-07-01 18:30"

