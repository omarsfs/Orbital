import csv

def read_csv(csvfilename):
    rows = ()
    with open(csvfilename) as csvfile:
        file_reader = csv.reader(csvfile)
        for row in file_reader:
            rows += (tuple(row), )
    return rows

data = read_csv('residences.csv')


def get_residence_type_lower():
    restype = []
    for row in data[1:]:
        if row[0] not in restype:
            restype += [row[0].lower()]
    output = []
    for res in restype:
        if res not in output:
            output += [res]
    return output

#Get each residence info
def get_residence_info(residence):
    output = ''
    for row in data[1:]:
        if row[1].lower() == residence:
            output += f'''{data[0][2]}: {row[2]} 

{data[0][3]}: {row[3]}

{data[0][4]}: 
{row[4]}

{data[0][5]}: {row[5]}
{data[0][6]}: {row[6]}

{data[0][7]}: {row[7]}
{data[0][8]}: {row[8]}
'''
    return output

def get_all_residences():
    currentres = ''
    output = ''
    for row in data[1:]:
        if output == '':
            output += row[0] + ':' + '\n' + row[1] + '\n'
            currentres = row[0]
        elif row[0] != currentres:
            output += '\n' + row[0] + ':' + '\n' + row[1] + '\n'
            currentres = row[0]
        else:
            output += row[1] + '\n'
    return output

print(get_all_residences())
def get_all_residences_lower():
    output = []
    for row in data[1:]:
        output += [row[1].lower()]
    return output

#For Keyboard
def get_residence_type_kb():
    restype = []
    for row in data[1:]:
        if row[0] not in restype:
            restype += [row[0]]
    return restype


def get_residence_kb(restype):
    output = []
    for row in data[1:]:
         if row[0].lower() == restype:
             output += [row[1]]
    return output

def get_every_res_dict():
    output = {}
    for row in data[1:]:
        output[row[1]] = []
    return output

def get_every_res_chatids():
    output = {}
    for row in data[1:]:
        output[row[1]] = {}
    return output

