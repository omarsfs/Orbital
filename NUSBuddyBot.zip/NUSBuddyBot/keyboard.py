from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
import courses
import residences
from telebot import types

courses_and_residences = {**courses.get_every_course_dict(), **residences.get_every_res_dict()}

course_button = KeyboardButton('Courses')
living_button = KeyboardButton('Campus Living')
keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add(course_button).add(living_button).to_python()


def faculty_keyboard():
    output = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    for fac in courses.get_faculties_kb():
        output.add(KeyboardButton(fac))
    return output.to_python()

def major_keyboard(faculty):
    output = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    for major in courses.get_majors_kb(faculty):
        output.add(KeyboardButton(major))
    return output.to_python()

def residence_keyboard():
    output = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    for res in residences.get_residence_type_kb():
        output.add(KeyboardButton(res))
    return output.to_python()

def residencetype_keyboard(res):
    output = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    for house in residences.get_residence_kb(res):
        output.add(KeyboardButton(house))
    return output.to_python()


#Echo
def js_echo_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    btn1 = types.KeyboardButton("Junior")
    btn2 = types.KeyboardButton("Senior")
    markup.add(btn1, btn2)
    return markup




