class Person:
    def __init__(self, chatid):
        self.chatid = chatid
        self.chatting = False

    def enter_chat(self):
        self.chatting = True

    def exit_chat(self):
        self.chatting = False

    def getchatid(self):
        return self.chatid

    def get_chat_status(self):
        return self.chatting


lstofusers = []

def add_user(chatid):
    global lstofusers
    lstofusers += [Person(chatid)]

def find_user(chatid):
    for person in lstofusers:
        if person.getchatid() == chatid:
            return person

def in_lstofusers(chatid):
    for person in lstofusers:
        if person.getchatid() == chatid:
            return True
    return False