buddy_chat_ids= []
def NO_USERS_BUD():
    return len(buddy_chat_ids)
chat_ids = []
def NO_USERS_CHAT():
    return len(chat_ids)
CHATS_STARTED = 0

COURSE_QUERIES = 0
RESIDENCE_QUERIES = 0


#Need to call the functions accordingly in NUSBUDDY and NUSCHATBOT
def buddy_user_inc(msgid): #done
    global buddy_chat_ids
    if msgid not in buddy_chat_ids:
        buddy_chat_ids += [msgid]

def chat_user_inc(msgid): #done
    global chat_ids
    if msgid not in chat_ids:
        chat_ids += [msgid]

def chat_start_inc(): #done
    global CHATS_STARTED
    CHATS_STARTED += 1

def course_queries_inc(): #done
    global COURSE_QUERIES
    COURSE_QUERIES += 1

def res_queries_inc(): #done
    global RESIDENCE_QUERIES
    RESIDENCE_QUERIES += 1

def get_stats_buddy():
    return f"Here are some stats for @NUSBudBot:\n\nNumber of course queries: {COURSE_QUERIES} \nNumber of residences queries: {RESIDENCE_QUERIES}\nTotal number of users for @NUSBudBot: {NO_USERS_BUD()}\n"


def get_stats_chat():
    return f"Here are some stats for @NusBudChatBot:\n\nChats started: {CHATS_STARTED}\nTotal number of users for @NusBudChatBot: {NO_USERS_CHAT()}"



