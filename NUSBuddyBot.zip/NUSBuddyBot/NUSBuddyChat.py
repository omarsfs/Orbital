import telebot
import keyboard
import courses,residences
import persons
import stats
import html

TOKEN = '5990843680:AAHzwiCeeQh-R4dHehTEgxpF0HgO4Pup8Uo'
BOTUSER = '@NusBudChatBot'

bot = telebot.TeleBot(token=TOKEN)

def dict_full(dict):
    for key in dict:
        if dict[key] == 0:
            return False
    return True

courses_and_residences = {**courses.get_every_course_chatids(), **residences.get_every_res_chatids()}
coded_c_and_r = {} #Senior: Junior
codes = ''
i = 0
code_number = '0'
for key in courses_and_residences:
    i += 1
    newcode = code_number + str(i)
    codes += key + ' - ' + newcode + '\n'
    coded_c_and_r[newcode] = {}

print(coded_c_and_r)


def other_chatid(msgid):
    for key in coded_c_and_r:
        if msgid in coded_c_and_r[key]:
            return coded_c_and_r[key][msgid]
    for course in coded_c_and_r:
        for senior in coded_c_and_r[course]:
            if msgid == coded_c_and_r[course][senior]:
                return senior

@bot.message_handler(commands=["start"])
def send_start_message(msg):
    stats.chat_user_inc(msg.chat.id)
    if not persons.in_lstofusers(msg.chat.id):
        persons.add_user(msg.chat.id)
    bot.send_message(chat_id=msg.chat.id, text="Hi, are you a senior or junior?", reply_markup=keyboard.js_echo_keyboard())

@bot.message_handler(commands=['code'])
def send_code_message(msg):
    if not persons.in_lstofusers(msg.chat.id):
        persons.add_user(msg.chat.id)
    bot.send_message(chat_id=msg.chat.id, text=codes)

@bot.message_handler(commands=['stats'])
def send_stats_message(msg):
    bot.send_message(chat_id=msg.chat.id, text=stats.get_stats_chat())

@bot.message_handler(commands=['info'])
def send_stats_message(msg):
    bot.send_message(chat_id=msg.chat.id, text="Head over to @NUSBudBot for more info on courses/residences!")

@bot.message_handler(commands=['exitchat'])
def exit_code_message(msg):
    otherchatid = 0
    course = 0
    delchatid = 0
    if not persons.in_lstofusers(msg.chat.id):
        bot.send_message(chat_id=msg.chat.id, text= "You are not currently in a chat, start one with /start")
    elif not persons.find_user(msg.chat.id).get_chat_status():
        bot.send_message(chat_id=msg.chat.id, text="You are not currently in a chat, start one with /start")
    else:
        #fix logic here
        for key in coded_c_and_r:  #Current senior
            if msg.chat.id in coded_c_and_r[key]:
                course = key
                otherchatid = coded_c_and_r[course][msg.chat.id]
                delchatid = msg.chat.id
                break


        for key in coded_c_and_r: #Current junior
            for senior in coded_c_and_r[key]:
                if msg.chat.id == coded_c_and_r[key][senior]:
                    otherchatid = senior
                    course = key
                    delchatid = senior
                    break

        if persons.in_lstofusers(msg.chat.id):
            coded_c_and_r[course].pop(delchatid)

        current = persons.find_user(msg.chat.id)
        other = persons.find_user(otherchatid)
        current.exit_chat()
        other.exit_chat()
        bot.send_message(chat_id=msg.chat.id, text="Chat has ended.")
        bot.send_message(chat_id=otherchatid, text= "Chat has ended.")

@bot.message_handler(content_types=['text', 'emoji','photo','audio','document','sticker','video'])
def handle_replies(msg):
    senior_chatid = 0
    junior_chatid = 0
    if not persons.in_lstofusers(msg.chat.id):
        persons.add_user(msg.chat.id)

    if persons.find_user(msg.chat.id).get_chat_status():
        #bot.send_message(chat_id=other_chatid(msg.chat.id), text=msg.text)
        content_type = msg.content_type
        if content_type == 'text':
            escaped_text = html.escape(msg.text)
            bot.send_message(other_chatid(msg.chat.id), escaped_text, parse_mode="HTML")
        elif content_type == 'photo':
            # Handle photo
            bot.send_photo(other_chatid(msg.chat.id), msg.photo[-1].file_id)  # Send the last photo from the array
        elif content_type == 'audio':
            # Handle audio
            bot.send_audio(other_chatid(msg.chat.id), msg.audio.file_id)
        elif content_type == 'document':
            # Handle document
            bot.send_document(other_chatid(msg.chat.id), msg.document.file_id)
        elif content_type == 'sticker':
            # Handle sticker
            bot.send_sticker(other_chatid(msg.chat.id), msg.sticker.file_id)
        elif content_type == 'video':
            # Handle video
            bot.send_video(other_chatid(msg.chat.id), msg.video.file_id)

    if not persons.find_user(msg.chat.id).get_chat_status():
        answer = msg.text.split(', ')

        if msg.text == 'Junior':
            bot.send_message(chat_id=msg.chat.id, text="Indicate the code of the specific course or residence you want to ask a senior about"
                                                       "\nTo check for the code for residence or course, use command /code")
        elif msg.text == 'Senior':
            bot.send_message(chat_id=msg.chat.id, text="Indicate your Telegram username and the code of the course/residence you wish to answer questions about as such: Username, Code."
                                                       "\nExample: Username, 001. "
                                                       "\nTo check for the code for residence or course, use command /code")


        elif (answer[0] == msg.chat.username or answer[0] == "@" + msg.chat.username) \
                and answer[1] in coded_c_and_r: #Senior replying and offering
            coded_c_and_r[answer[1]][msg.chat.id] = 0
            bot.send_message(chat_id=msg.chat.id,text="Thank you for offering to answer questions, " + msg.chat.username + "!")
        elif answer[0] in coded_c_and_r and len(answer) == 1: #Junior replying
            if dict_full(coded_c_and_r[answer[0]]):
                bot.send_message(chat_id=msg.chat.id, text="Sorry, there aren't any seniors available for this selection yet!")
            else:
                for key in coded_c_and_r[answer[0]]: #Has a senior(s)
                    if coded_c_and_r[answer[0]][key] == 0:
                        coded_c_and_r[answer[0]][key] = msg.chat.id
                        senior_chatid = key
                        #print(senior_chatid)
                        #junior_chatid = msg.chat.id
                        #print(junior_chatid)
                        persons.find_user(msg.chat.id).enter_chat()
                        persons.find_user(senior_chatid).enter_chat()
                        bot.send_message(chat_id=msg.chat.id, text="You have been paired. Have fun!")
                        bot.send_message(chat_id=senior_chatid, text="You have been paired. Have fun!")
                        stats.chat_start_inc()
                        break

        else:
            bot.send_message(chat_id=msg.chat.id, text="Send a message or command the bot can understand.")
        # print(senior_chatid)
        # print(junior_chatid)
    print(coded_c_and_r)
        #If there are seniors available, their chatid will be paired. Else, juniors will be sent the message






bot.polling()