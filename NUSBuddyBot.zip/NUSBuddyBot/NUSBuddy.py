from typing import Final
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackContext
import courses
import residences
import reminder
from reminder import job_data
import keyboard
import stats

TOKEN: Final = '6077961592:AAFlMC5HP_wEBQLyGjjPADDgU9r7bPHjSfg'
BOT_USERNAME: Final = '@NUSBudBot'


#Commands
async def start_command(update: Update, context: CallbackContext):
    stats.buddy_user_inc(update.message.chat_id)
    await update.message.reply_text("Hello, what do you want to find out today?", reply_markup=keyboard.keyboard)

async def stats_command(update: Update, context: CallbackContext):
    await update.message.reply_text(stats.get_stats_buddy())
async def chat_command(update: Update, context: CallbackContext):
    await update.message.reply_text("Head over to @NusBudChatBot to start a chat, or help a junior out!")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("This bot can help you get the information you need on NUS! \nKey in /start to start using the bot!")

async def majors_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f'The list of majors are as follows: \n \n'
                                    f'{courses.get_all_majors()}')
    
async def residences_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f'The list of residences are as follows: \n \n'
                                    f'{residences.get_all_residences()}')

async def set_reminder_command(update: Update, context: CallbackContext):
    print('set reminder cmd called')
    chat_id = update.message.chat_id
    user_input = update.message.text.split(' ', 1)
    if len(user_input) < 2:
        await update.message.reply_text("Invalid format. To set a reminder, please use the format: \nevent, YYYY-MM-DD HH:MM\nFor example, Hall Application, 2023-07-01 18:30")
        return
    
    event, datetime_str = user_input[1].split(',', 1)
    event = event.strip()
    datetime_str = datetime_str.strip()

    response = reminder.add_reminder(event, datetime_str, chat_id, context)
    await update.message.reply_text(response)

async def reminder_list_command(update: Update, context: CallbackContext):
    reminders = ""
    if job_data:
        for job, job_obj in job_data.items():
            datetime_split = (str(job_obj['datetime']))[:-9]
            reminders += str(job_obj['event']) + ' at ' + datetime_split + "\n"
        message = "Here are the reminders:\n" + reminders
    else:
        message = "There are no reminders."

    await update.message.reply_text(message)


async def handle_response(text: str, update: Update, context: CallbackContext):
    first = ''
    second = ''
    processed: str = text.lower()
    if ',' in text:
        user_and_course = text.split(', ')
        first = user_and_course[0]
        second = user_and_course[1]
        print(user_and_course)
        print(first)
        print(second)
        

    #Courses
    if 'courses' in processed:
        await update.message.reply_text('Which faculty are you interested in?', reply_markup=keyboard.faculty_keyboard())
    elif processed in courses.get_faculties_lower():
        await update.message.reply_text('What major are you interested in?', reply_markup=keyboard.major_keyboard(processed))
    elif processed in courses.get_all_majors_lower():
        stats.course_queries_inc()
        await update.message.reply_text(f'Here is some info regarding the major you picked! \n\n{courses.get_major_info(processed)}')

    #Residential Options
    elif 'campus living' in processed:
        await update.message.reply_text('What type of residences are you interested in?',
                                        reply_markup=keyboard.residence_keyboard())
    elif processed in residences.get_residence_type_lower():
        await update.message.reply_text('Which residence are you interested in?',
                                        reply_markup=keyboard.residencetype_keyboard(processed))
    elif processed in residences.get_all_residences_lower():
        stats.res_queries_inc()
        await update.message.reply_text(f'Here is some info regarding the residence you picked! '
                                        f'\n\n{residences.get_residence_info(processed)}')

    else:
        await update.message.reply_text('Reply with something I understand!')



async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message_type: str = update.message.chat.type
    text: str = update.message.text

    print(f'User ({update.message.chat.id}) in {message_type}: "{text}"')

    if message_type == 'group':
        if BOT_USERNAME in text:
            new_text: str = text.replace(BOT_USERNAME, '').strip()
            response: str = await handle_response(new_text, update, context)
        else:
            return
    else:
        response: str = await handle_response(text, update, context)

    print('Bot:', response)
    await update.message.reply_text(response)

async def error(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print(f'Update {update} caused error {context.error}')

if __name__ == '__main__':
    print('Starting bot...')
    app = Application.builder().token(TOKEN).build()

    #Commands
    app.add_handler(CommandHandler('start', start_command))
    app.add_handler(CommandHandler('chat', chat_command))
    app.add_handler(CommandHandler('help', help_command))
    app.add_handler(CommandHandler('majors', majors_command))
    app.add_handler(CommandHandler('residences', residences_command))
    app.add_handler(CommandHandler('setreminder', set_reminder_command))
    app.add_handler(CommandHandler('reminderlist', reminder_list_command))
    app.add_handler(CommandHandler('stats', stats_command))

    #Messages
    app.add_handler(MessageHandler(filters.TEXT, handle_message))

    #Errors
    app.add_error_handler(error)

    #Polls the bot
    print('Polling...')
    app.run_polling(poll_interval=1)

