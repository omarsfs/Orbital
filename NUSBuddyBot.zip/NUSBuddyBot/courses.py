import csv

def read_csv(csvfilename):
    rows = ()
    with open(csvfilename) as csvfile:
        file_reader = csv.reader(csvfile)
        for row in file_reader:
            rows += (tuple(row), )
    return rows

data = read_csv('majors.csv')

def get_faculties_lower():
    fac = []
    for row in data[1:]:
        if row[0] not in fac:
            fac += [row[0].lower()]
    output = []
    for faculty in fac:
        output += [faculty]
    return output

#Get each majors info
def get_major_info(major):
    output = ''
    for row in data[1:]:
        if row[1].lower() == major:
            output += f'''{data[0][2]}: {row[2]} 
{data[0][3]}: {row[3]}
{data[0][4]}: {row[4]}
{data[0][5]}: {row[5]}

{data[0][6]}: {row[6]}

{data[0][7]}: {row[7]}
'''
    return output

def get_all_majors():
    currentfac = ''
    output = ''
    for row in data[1:]:
        if output == '':
            output += row[0] + ':' + '\n' + row[1] + '\n'
            currentfac = row[0]
        elif row[0] != currentfac:
            output += '\n' + row[0] + ':' + '\n' + row[1] + '\n'
            currentfac = row[0]
        else:
            output += row[1] + '\n'
    return output

def get_all_majors_lower():
    output = []
    for row in data[1:]:
        output += [row[1].lower()]
    return output

#For Keyboard
def get_faculties_kb():
    fac = []
    for row in data[1:]:
        if row[0] not in fac:
            fac += [row[0]]
    return fac

def get_majors_kb(faculty):
    output = []
    for row in data[1:]:
         if row[0].lower() == faculty:
             output += [row[1]]
    return output

#Dictionary

def get_every_course_dict():
    output = {}
    for row in data[1:]:
        output[row[1]] = []
    return output

def get_every_course_chatids():
    output = {}
    for row in data[1:]:
        output[row[1]] = {}
    return output
